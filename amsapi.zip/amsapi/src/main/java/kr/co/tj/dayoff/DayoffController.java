package kr.co.tj.dayoff;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.co.tj.dayoff.dto.DayoffDTO;
import kr.co.tj.dayoff.dto.DayoffEntity;
import kr.co.tj.dayoff.dto.DayoffRequest;
import kr.co.tj.dayoff.dto.DayoffResponse;
import kr.co.tj.member.MemberEntity;
import kr.co.tj.notice.NoticeDTO;
import kr.co.tj.notice.NoticeEntity;

@RestController
@RequestMapping("/dayoff")
public class DayoffController {
	
	@Autowired
	private DayoffService dayoffService;
	

//	@GetMapping("/all")
//	public ResponseEntity<?> findAll(){
//		
//		Map<String, Object> map = new HashMap<>();
//		
//		try {
//			List<DayoffDTO> list_dto = dayoffService.findAll();
//			map.put("result", list_dto);
//			return ResponseEntity.ok().body(map);
//			
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			map.put("result", "전체 연차상신 내역을 불러오는 데 실패했습니다.");
//			return ResponseEntity.badRequest().body(map);
//		}
//	}
	
	@GetMapping("/all")
	public ResponseEntity<?> findAll(@RequestParam(name = "pageNum", required = false, defaultValue = "0") int pageNum){
		Map<String, Object> map = new HashMap<>();

		
		try {
			Page<DayoffDTO> page_dto = dayoffService.findAll(pageNum);
			map.put("result", page_dto);
			return ResponseEntity.ok().body(page_dto);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			map.put("result", "전체 공지사항 페이지 조회에 실패했습니다.");
			return ResponseEntity.badRequest().body(map);
		}
		
		
		
	}
	
	
	
	@GetMapping("/{username}")
	public ResponseEntity<?> findByUsername(@PathVariable("username") String username){
		
		Map<String, Object> map = new HashMap<>();
		
		if(username==null) {
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요.");
		}
	

			
		try {
			DayoffDTO dayoffDTO = dayoffService.findByUsername(username);
			map.put("result", dayoffDTO);
			return ResponseEntity.ok().body(map);
			
		} catch (Exception e) {
			e.printStackTrace();
			map.put("result", "내 연자 확인에 실패하였습니다.");
			return ResponseEntity.badRequest().body(map);
		}
			
			
	
			
	}

	
	
	

	
	
	//연차상신 글 작성
	@PostMapping("/create")
	public ResponseEntity<?> create(@RequestBody DayoffRequest dayoffRequest ){
		
		
		
		 DayoffDTO dayoffDTO = DayoffDTO.toDayoffDTO(dayoffRequest);
		System.out.println(dayoffDTO);
		
		if(dayoffDTO==null) {
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요.1");
		}
		
		if(dayoffDTO.getUsername()==null || dayoffDTO.getUsername().equals("")) {
			System.out.println(dayoffDTO.getUsername().toString());
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요.2");
		}
		

		
		if(dayoffDTO.getType()==null|| dayoffDTO.getType().equals("")) {
			System.out.println(dayoffDTO.getType());
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요.4");
			
		}
		
		if(dayoffDTO.getStartDate()==null|| dayoffDTO.getStartDate().equals("")) {
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요.5");
		}
		
		if(dayoffDTO.getEndDate()==null|| dayoffDTO.getEndDate().equals("")) {
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요.5-1");
		}
		

		
		//시작일이 종료일보다 크지 않은지 점검
		if(dayoffDTO.getStartDate().compareTo( dayoffDTO.getEndDate()) > 0) {
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요.5-2");

		}
		
		if(dayoffDTO.getReason()==null|| dayoffDTO.getReason().equals("")) {
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요.6");
		}
		
		
			try {
				dayoffDTO = dayoffService.create(dayoffDTO);
				DayoffResponse dayoffResponse = dayoffDTO.toDayoffResponse();
		
				return ResponseEntity.status(HttpStatus.CREATED).body(dayoffResponse);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("연차상신 실패");
 
			}
			
			

	}
	
	
		

}
