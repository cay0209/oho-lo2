package kr.co.tj.dayoff.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DayoffRequest {//연차상신 글쓰기할 때 사용
	
	private long id;
	
	private String username;
	
	private String type; //연차구분(연차/반차)
	//만약 type이 연차면 사용가능연차개수에서 1, 반차면 0.5 차감
	
	private Date startDate;//연차 시작일
	private Date endDate;//연차 종료일
	//만약 연차 시작일과 연차 종료일이 같으면 dayoff 0.5 차감
	//연차 시작일과 연차 종료일이 다르면 연차 시작일-연차 종료일만큼 remainingDayoff에서 차감 
	
	private String reason; //연차사유
	
	private Date createDate;
	private Date updateDate;

	

	
	
	

}
