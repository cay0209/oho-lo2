package kr.co.tj.attendance;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AttendanceRepository extends JpaRepository<AttendanceEntity, Long>{

	List<AttendanceEntity> findByUsername(String username);



}
