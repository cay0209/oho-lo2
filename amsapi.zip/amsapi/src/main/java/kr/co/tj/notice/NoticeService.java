package kr.co.tj.notice;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
public class NoticeService {

	@Autowired
	private NoticeRepository noticeRepository;
	
	// 조회수 증가 구현 위해 추가함(findById에서 사용)
	private int findByIdCallCount = 0;

	public NoticeDTO create(NoticeDTO noticeDTO) {

		NoticeEntity noticeEntity = noticeDTO.toEntity();
//		NoticeEntity noticeEntity = new ModelMapper().map(noticeDTO, NoticeEntity.class);

		noticeEntity.setUsername(noticeDTO.getUsername());
		noticeEntity.setName(noticeDTO.getName());
		noticeEntity.setSubject(noticeDTO.getSubject());
		noticeEntity.setContent(noticeDTO.getContent());

		// 현재 날짜 및 시간 가져오기
		Date currentDate = new Date();

		// 날짜 포맷팅을 위한 SimpleDateFormat 생성
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		// 년-월-일 시:분:초 형식으로 날짜를 문자열로 변환
		String formattedDate = sdf.format(currentDate);

		// 생성 및 업데이트 날짜 설정
		noticeEntity.setCreatedDate(formattedDate);
		noticeEntity.setUpdatedDate(formattedDate);
		noticeEntity.setReadCount(0L);

		noticeEntity = noticeRepository.save(noticeEntity);

		return NoticeDTO.toDto(noticeEntity);
	}



	public NoticeDTO findById(Long id) {
		Optional<NoticeEntity> optional = noticeRepository.findById(id);

		if (!optional.isPresent()) {
			throw new RuntimeException("해당하는 글이 존재하지 않습니다.");
		}

		NoticeEntity noticeEntity = optional.get();

		findByIdCallCount++;

		if (findByIdCallCount % 2 == 1) {
			// 홀수 번째 호출일 때만 readCount를 증가
			noticeEntity.setReadCount(noticeEntity.getReadCount() + 1);
			noticeEntity = noticeRepository.save(noticeEntity);
		}

		return new ModelMapper().map(noticeEntity, NoticeDTO.class);
	}

//	public List<NoticeDTO> findAll() {
//
//		List<NoticeEntity> list_entity = noticeRepository.findAll();
//		List<NoticeDTO> list_dto = new ArrayList<NoticeDTO>();
//		
//		for(NoticeEntity e : list_entity ) {
//			list_dto.add(NoticeDTO.toDto(e));
//		}
//		
//		
//		return list_dto;
//	}

//	public Page<NoticeDTO> findAll() {
//
//		List<NoticeEntity> list_entity = noticeRepository.findAll();
//		List<NoticeDTO> list_dto = new ArrayList<NoticeDTO>();
//
//		for (NoticeEntity e : list_entity) {
//			list_dto.add(NoticeDTO.toDto(e));
//		}
//
//		return list_dto;
//	}

    public Page<NoticeDTO> findAll(int pageNum) {

        List<Sort.Order> sortList = new ArrayList<>();
        
        //id를 기준으로 내림차순 정렬
        sortList.add(Sort.Order.desc("id"));
        
        //pageable객체 생성 : 페이지번호, 한 페이지에 보여지는 개수, 정렬 순서 설정
        Pageable pageable = PageRequest.of(pageNum, 10, Sort.by(sortList));

        //리포지토리에서 pageable사용해 페이지별로 데이터 가져옴
        Page<NoticeEntity> page_entity = noticeRepository.findAll(pageable);

        //엔티티->dto형태로 변환.
        Page<NoticeDTO> page_dto = page_entity.map(noticeEntity -> NoticeDTO.toDto(noticeEntity));
        
        return page_dto;

   }

	@Transactional
	public NoticeDTO update(NoticeDTO noticeDTO) {
		//글번호로 레포지토리에 해당 글 존재여부 확인
		Optional<NoticeEntity> optional = noticeRepository.findById(noticeDTO.getId());

		if (!optional.isPresent()) {
			throw new RuntimeException("해당하는 글이 존재하지 않습니다.");
		}

		NoticeEntity noticeEntity = optional.get();

		noticeEntity.setSubject(noticeDTO.getSubject());
		noticeEntity.setContent(noticeDTO.getContent());
		

		// 홀수 번째 호출일 때만 readCount를 증가
		noticeEntity.setReadCount(noticeEntity.getReadCount()-2);
		noticeEntity = noticeRepository.save(noticeEntity);

		
		// 현재 날짜 및 시간 가져오기
		Date currentDate = new Date();

		// 날짜 포맷팅을 위한 SimpleDateFormat 생성
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		// 년-월-일 시:분:초 형식으로 날짜를 문자열로 변환
		String formattedDate = sdf.format(currentDate);
		noticeEntity.setUpdatedDate(formattedDate);

		noticeEntity = noticeRepository.save(noticeEntity);

		return NoticeDTO.toDto(noticeEntity);
	}

	@Transactional
	public void delete(NoticeDTO noticeDTO) {

		Optional<NoticeEntity> optional = noticeRepository.findById(noticeDTO.getId());

		if (!optional.isPresent()) {
			throw new RuntimeException("해당하는 글이 존재하지 않습니다.");
		}

		NoticeEntity noticeEntity = optional.get();

		noticeRepository.delete(noticeEntity);

	}

}
