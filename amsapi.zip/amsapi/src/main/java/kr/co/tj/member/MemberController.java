package kr.co.tj.member;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.co.tj.notice.NoticeDTO;
import net.bytebuddy.asm.Advice.OffsetMapping.Sort;

@RestController
@RequestMapping("/members")
public class MemberController {
	
	@Autowired
	private MemberService memberService;
	
	//1명 정보 찾기	
	@GetMapping("/detail/{username}")
	public ResponseEntity<?> findByUsername(@PathVariable("username") String username){
		
		Map<String, Object> map = new HashMap<>();
		
		if(username==null) {
			throw new RuntimeException("입력한 정보를 다시 확인해 주세요.");
		}

			
		try {
			MemberDTO memberDTO = memberService.findByUsername(username);
			map.put("result", memberDTO);
			return ResponseEntity.ok().body(map);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			map.put("result", "내정보보기 실패");
			return ResponseEntity.badRequest().body(map);
		}
		
	}
	
	
	
//	@GetMapping("/all")
//	public ResponseEntity<?> findAll(){
//		
//		Map<String, Object> map = new HashMap<>();
//		
//		try {
//			List<MemberDTO> list = memberService.findAll();
//			map.put("result", list);
//			return ResponseEntity.ok().body(map);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//			map.put("result", "전체회원 조회 실패");
//			return ResponseEntity.ok().body(map);
//		}
//	}
	
	//페이징 추가
	@GetMapping("/all")
	public ResponseEntity<?> findAll(@RequestParam(name = "pageNum", required = false, defaultValue = "0") int pageNum){
		Map<String, Object> map = new HashMap<>();

		
		try {
			Page<MemberDTO> page_dto = memberService.findAll(pageNum);
			map.put("result", page_dto);
			return ResponseEntity.ok().body(page_dto);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			map.put("result", "전체 회원 페이지 조회에 실패했습니다.");
			return ResponseEntity.badRequest().body(map);
		}
		
		
		
	}

	
	
	//삭제
	@DeleteMapping("/delete")
	public ResponseEntity<?> delete(@RequestBody MemberDTO memberDTO){
		
		Map<String, Object> map = new HashMap<>();
		
		
		if(memberDTO == null) {
			throw new RuntimeException("입력한 정보가 적절한지 다시 확인해주세요.1");
		}
		
		if(memberDTO.getUsername() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 적절한지 다시 확인해주세요.2");
		}
		
		if(memberDTO.getPassword() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 적절한지 다시 확인해주세요.3");
		}
		
		if(memberDTO.getPassword2() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 적절한지 다시 확인해주세요.4");
		}
		
		if(!memberDTO.getPassword().equals(memberDTO.getPassword2())) {
			return ResponseEntity.badRequest().body("입력한 정보가 적절한지 다시 확인해주세요.5");
		}
		
		
		
		try {
			memberService.delete(memberDTO);
			map.put("result", "회원탈퇴 성공");
			return ResponseEntity.ok().body(map);
			
		} catch (Exception e) {
			e.printStackTrace();
			map.put("result", "회원탈퇴 실패");
			return ResponseEntity.badRequest().body(map);
			
		}
		
	}
	
	@PutMapping("/update")
	private ResponseEntity<?> update(@RequestBody MemberDTO memberDTO){
		
		Map<String, Object> map = new HashMap<>();
		
		if(memberDTO == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.1");
		}
		
		if(memberDTO.getUsername() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.2");
		}
		
		if(memberDTO.getOrgPassword() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.3");
		}
		
		
		if(memberDTO.getPassword() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.4");
		}
		
		if(memberDTO.getPassword2() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.5");
		}
		
		if(memberDTO.getOrgPassword().equals(memberDTO.getPassword())) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.6");
		}
		
		if(!memberDTO.getPassword().equals(memberDTO.getPassword2())) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.7");
		}
		
		if(memberDTO.getName() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.8");
		}
		
		if(memberDTO.getHiredDate() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.9");
		}
		
		if(memberDTO.getPhoneNumber() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.10");
		}
		
		if(memberDTO.getEmail() == null) {
			return ResponseEntity.badRequest().body("입력한 정보가 맞는지 다시 확인해주세요.11");

		}
		
	
		
		try {
			memberDTO = memberService.update(memberDTO);
			map.put("result", memberDTO);
			return ResponseEntity.ok().body(map);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			map.put("result", "회원정보 수정 실패");
			return ResponseEntity.badRequest().body(map);
		}
	}
	
// AuthController 생성으로 삭제(인증 없이 가능하게 하려고)
//	@PostMapping("/create")
//	public ResponseEntity<?> create(@RequestBody MemberDTO memberDTO){
//		
//		Map<String, Object> map = new HashMap<>();
//		
//		if(memberDTO == null) {
//			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.1");
//			return ResponseEntity.badRequest().body(map);
//			
//		}
//		
//		if(memberDTO.getUsername() == null || memberDTO.getUsername().equals("")) {
//			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.2");
//			return ResponseEntity.badRequest().body(map);
//
//		}
//		
//		if(memberDTO.getPassword() == null|| memberDTO.getPassword().equals("")) {
//			throw new RuntimeException("입력한 정보가 적절한지 다시 확인해주세요.3");
//
//		}
//		
//		
//		if(memberDTO.getPassword2() == null ||memberDTO.getPassword2().equals("")) {
//			System.out.println(memberDTO.getPassword().toString());
//			System.out.println(memberDTO.getPassword2().toString());
//			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.4");
//			
//			return ResponseEntity.badRequest().body(map);
//
//		}
//		
//		//비밀번호 일치여부 확인 추가
//		if(!memberDTO.getPassword().equals(memberDTO.getPassword2())){
//			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.4-1");
//			return ResponseEntity.badRequest().body(map);
//
//		}
//		
//		if(memberDTO.getName() == null) {
//			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.5");
//			return ResponseEntity.badRequest().body(map);
//
//		}
//		
//		//생년월일 형식 지정
//		 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//		    String hiredDate;
//		    
//		    try {
//		        hiredDate = memberDTO.getHiredDate();
//		    } catch (Exception e) {
//		        map.put("result", "생년월일을 0000-00-00 형식에 맞게 입력해 주세요.");
//		        return ResponseEntity.badRequest().body(map);
//		    }
//		    
//		if(memberDTO.getHiredDate() == null) {
//			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.6");
//			return ResponseEntity.badRequest().body(map);
//
//		}
//		
//		
//		
//		if(memberDTO.getPhoneNumber() == null) {
//			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.7");
//			return ResponseEntity.badRequest().body(map);
//
//		}
//		
//		if(memberDTO.getEmail() == null) {
//			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.8");
//			return ResponseEntity.badRequest().body(map);
//
//		}
//		
//
//		
//		try {
//			memberDTO = memberService.create(memberDTO);
//			map.put("result", memberDTO);
//			return ResponseEntity.ok().body(map);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//			map.put("result", e.getMessage());
//			return ResponseEntity.badRequest().body(map);
//		}
//		
//	}
	
	
	
	
		
	

}
