package kr.co.tj.attendance;

import java.time.LocalDateTime;

import kr.co.tj.notice.NoticeDTO;
import kr.co.tj.notice.NoticeEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AttendanceDTO {

	private long id;
	
	private String username;
	
	private String name;
	
	private String department;

	
	private String click="시간 기록";
	
	private String clickTime;


	
	//entity->dto
	public static AttendanceDTO toDto(AttendanceEntity attendanceEntity) {
		return AttendanceDTO.builder()
				.id(attendanceEntity.getId())
				.username(attendanceEntity.getUsername())
				.name(attendanceEntity.getName())
				.department(attendanceEntity.getDepartment())
				.clickTime(attendanceEntity.getClickTime())
				.build();
	} 
	
	 
}
