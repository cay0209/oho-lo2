package kr.co.tj.notice;

import java.time.LocalDateTime;
import java.util.Date;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NoticeDTO {
	
	private Long id;
	
	private String username;
	
	private String subject;
	
	private String content;
	
	private String name;
	
//	private String password;
	

	private String createdDate;
	private String updatedDate;

	private Long readCount;
	
	private String token;
	
	
	
//dto->entity
	public NoticeEntity toEntity() {
		return NoticeEntity.builder()
				.username(username)
				.name(name)
			//.password(password)
				.subject(subject)
				.content(content)
				.createdDate(createdDate)
				.updatedDate(updatedDate)
				.build();
	}
	
	//entity->dto
	public static NoticeDTO toDto(NoticeEntity noticeEntity) {
		return NoticeDTO.builder()
				.id(noticeEntity.getId())
				.username(noticeEntity.getUsername())
				.name(noticeEntity.getName())
//				.password(noticeEntity.getPassword())
				.subject(noticeEntity.getSubject())
				.content(noticeEntity.getContent())
				.createdDate(noticeEntity.getCreatedDate())
				.updatedDate(noticeEntity.getUpdatedDate())
				.readCount(noticeEntity.getReadCount())
				.build();
	}




}
