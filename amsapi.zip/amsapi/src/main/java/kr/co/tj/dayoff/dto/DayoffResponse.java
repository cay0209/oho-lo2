package kr.co.tj.dayoff.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DayoffResponse {
	
	private long id;
	
	private String username;
	
	private String type; //연차구분(연차/반차)
	
	private String hiredDate; //memberEntity에서 가져오고 싶음

	
	private Date startDate;//연차 시작일
	private Date endDate;//연차 종료일
	
	private String reason; //연차사유
	
	private Date createDate;
	private Date updateDate;

}
