package kr.co.tj.notice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import kr.co.tj.attach.UploadFileEntity;
import kr.co.tj.attach.UploadFileService;

@RestController
@RequestMapping("/notice")
public class NoticeController {
	
	@Autowired
	private NoticeService noticeService;
	
	@Autowired
	private UploadFileService uploadFileService;
	
	@DeleteMapping("/delete")
	public ResponseEntity<?> delete(@RequestBody NoticeDTO noticeDTO){
		
		Map<String, Object> map = new HashMap<>();
		
		try {
			noticeService.delete(noticeDTO);
			map.put("result", "삭제 완료");
			return ResponseEntity.ok().body(noticeDTO);
			
		} catch (Exception e) {
			e.printStackTrace();
			map.put("result", "삭제 실패");
			return ResponseEntity.badRequest().body(map);
		}
		
	}
	
	
	@PutMapping("/update")
	public ResponseEntity<?> update(@RequestBody NoticeDTO noticeDTO){
		
		Map<String, Object> map = new HashMap<>();
		
		if(noticeDTO==null) {
			throw new RuntimeException("입력한 내용이 적절한지 다시 확인해주세요.");
		}
		

		
		try {
			noticeDTO = noticeService.update(noticeDTO);
			map.put("result", noticeDTO);
			return ResponseEntity.ok().body(noticeDTO);
			
		} catch (Exception e) {
			e.printStackTrace();
			map.put("result", "공지사항 수정에 실패했습니다.");
			return ResponseEntity.badRequest().body(map);
		}
		
		
	}
	
	
//	@GetMapping("/all")
//	public ResponseEntity<?> findAll(){
//		Map<String, Object> map = new HashMap<>();
//
//		
//		try {
//			List<NoticeDTO> list_dto = noticeService.findAll();
//			map.put("result", list_dto);
//			return ResponseEntity.ok().body(list_dto);
//			
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			map.put("result", "전체 공지사항 조회에 실패했습니다.");
//			return ResponseEntity.badRequest().body(map);
//		}
//		
//		
//		
//	}
	
	@GetMapping("/all")
	public ResponseEntity<?> findAll(@RequestParam(name = "pageNum", required = false, defaultValue = "0") int pageNum){
		Map<String, Object> map = new HashMap<>();

		
		try {
			Page<NoticeDTO> page_dto = noticeService.findAll(pageNum);
			map.put("result", page_dto);
			return ResponseEntity.ok().body(page_dto);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			map.put("result", "전체 공지사항 페이지 조회에 실패했습니다.");
			return ResponseEntity.badRequest().body(map);
		}
		
		
		
	}
	
	
	//글번호로 글 1개 조회하기
	@GetMapping("/detail/{id}")
	public ResponseEntity<?> findById(@PathVariable("id") Long id){
		
		Map<String, Object> map = new HashMap<>();
		
		if(id==null) {
			throw new RuntimeException("입력한 정보를 다시 확인해 주세요.");
		}
		
		try {
			NoticeDTO noticeDTO = noticeService.findById(id);
			map.put("result", noticeDTO);
			System.out.println(noticeDTO);
			return ResponseEntity.ok().body(map);
			
		} catch (Exception e) {
			e.printStackTrace();
			map.put("result", "공지사항 조회에 실패했습니다.");
			return ResponseEntity.badRequest().body(map);
		}
		
	}
	
	
	//공지글 작성하기
	@PostMapping("/create")
	public ResponseEntity<?> create(@RequestBody NoticeDTO noticeDTO){
		
		Map<String, Object> map = new HashMap<>();
		
		if(noticeDTO == null) {
			throw new RuntimeException("입력한 정보를 다시 확인해주세요.1");
		}
		
		if(noticeDTO.getUsername()==null || noticeDTO.getUsername().equals("")) {
			throw new RuntimeException("입력한 정보를 다시 확인해주세요.2");
		}
		
		
		if(noticeDTO.getSubject()==null || noticeDTO.getSubject().equals("")) {
			throw new RuntimeException("입력한 정보를 다시 확인해주세요.3");
		}
		
		if(noticeDTO.getContent()==null|| noticeDTO.getContent().equals("")) {
			throw new RuntimeException("입력한 정보를 다시 확인해주세요.4");
		}
		
		
		
		
		try {
			noticeDTO = noticeService.create(noticeDTO);
			map.put("result", noticeDTO);
			return ResponseEntity.ok().body(map);
			
		} catch (Exception e) {
			e.printStackTrace();
			map.put("result", "입력 실패");
			return ResponseEntity.badRequest().body(map);
		}
		
	}
	
	
	
	
	
//	@PostMapping("/fileUpload")
//	public ResponseEntity<?> uploadFile(MultipartHttpServletRequest mRequest){
//		
//		
//		Map<String, Object> map = new HashMap<>();
//		
//		String id = mRequest.getParameter("id");
//		
//		MultipartFile file1 = mRequest.getFile("file1");
//		
//		
//		try {
//			byte[] bytes = file1.getBytes();
//			UploadFileEntity uploadFileEntity = uploadFileService.uploadFile(bytes);
//			
//
//
////bytes = Base64.encodeBase64(bytes);
//
//String strBytes = new String (bytes , "UTF-8");
//
//map.put("bytes", strBytes);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		
//		map.put("result", "ok");
//		
//		return ResponseEntity.ok().body(map);
//
//	
//	}

}
