package kr.co.tj.attendance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.co.tj.member.MemberDTO;
import kr.co.tj.notice.NoticeDTO;
import kr.co.tj.notice.NoticeEntity;



@RestController
@RequestMapping("/attendance")
public class AttendanceController {
	
	@Autowired
	private AttendanceService attendanceService;
	
	//전체 출퇴근시간 확인
//	@GetMapping("/all")
//	public ResponseEntity<?> allClickTimes(){
//		
//		Map<String, Object> map = new HashMap<>();
//		
//		
//		try {
//			List<AttendanceDTO> list_dto = attendanceService.allClickTimes();
//			map.put("result", list_dto);
//			return ResponseEntity.ok().body(map);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//			map.put("result", "전체 출퇴근시간 확인 실패");
//			return ResponseEntity.badRequest().body(map);
//		}
//	}
	
	@GetMapping("/all")
	public ResponseEntity<?> findAll(@RequestParam(name = "pageNum", required = false, defaultValue = "0") int pageNum){
		Map<String, Object> map = new HashMap<>();

		
		try {
			Page<AttendanceDTO> page_dto = attendanceService.findAll(pageNum);
			map.put("result", page_dto);
			return ResponseEntity.ok().body(page_dto);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			map.put("result", "전체 공지사항 페이지 조회에 실패했습니다.");
			return ResponseEntity.badRequest().body(map);
		}
		
		
		
	}
	
	
	
	//내 출퇴근시간 확인
	@GetMapping("/{username}")
	public ResponseEntity<?> myClickTimes(@PathVariable("username") String username){
	
		Map<String, Object> map = new HashMap<>();
		
		if(username==null) {
			throw new RuntimeException("해당하는 회원 정보를 찾을 수 없습니다.");
		}
		
		try {
			List<AttendanceDTO> list_dto = attendanceService.findByUsername(username);
			map.put("result", list_dto);
			System.out.println(list_dto.toString());
			return ResponseEntity.ok().body(map);
			
		} catch (Exception e) {
			e.printStackTrace();
			map.put("result", "내 출퇴근기록 확인 실패");
			return ResponseEntity.badRequest().body(map);
		} 
		
	}
	
	
	//출퇴근시간 기록하기
	@PostMapping("")
	public ResponseEntity<?> clickTime(@RequestBody AttendanceDTO attendanceDTO){
		
		Map<String, Object> map = new HashMap<>();
		
		if(attendanceDTO==null) {
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요.");
		}
		
		
		
		
		System.out.println(attendanceDTO.toString());
		
		
		try {
			attendanceDTO = attendanceService.clickTime(attendanceDTO);
			map.put("result", attendanceDTO.getClickTime());
			return ResponseEntity.ok().body(map);
			
		} catch (Exception e) {
			e.printStackTrace();
			map.put("result", "시간 기록 실패");
			return ResponseEntity.badRequest().body(map);
		}
		
		

		
		
	
	}
}
