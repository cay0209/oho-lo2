package kr.co.tj.member;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import kr.co.tj.dayoff.DayoffService;
import kr.co.tj.dayoff.dto.DayoffDTO;
import kr.co.tj.notice.NoticeDTO;
import kr.co.tj.notice.NoticeEntity;
import kr.co.tj.sec.TokenProvider;

@Service
public class MemberService {

	@Autowired
	private MemberRepository memberRepository;
	
	@Autowired
	private TokenProvider tokenProvider;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	

	


	public MemberDTO login(MemberDTO memberDTO) {

		//기존회원 중복확인
		Optional<MemberEntity> memberEntity = memberRepository.findByUsername(memberDTO.getUsername());
			
		if(!memberEntity.isPresent()) {
			throw new RuntimeException("해당하는 회원이 존재하지 않습니다.");
		}
		
		MemberEntity member = memberEntity.get();
		
		 // 비밀번호 일치 여부 확인
		if (!passwordEncoder.matches(memberDTO.getPassword(), member.getPassword())) {
			throw new RuntimeException("비밀번호가 일치하지 않습니다.");
		}
		
		//로그인 성공 -> 토큰 생성
		String token = tokenProvider.create(member);
		
		memberDTO = new ModelMapper().map(member, MemberDTO.class);
		
		// 토큰을 사용자에 보냄(나중에 사용자는 헤더에 토큰을 넣어서 서버에 서비스 요청)
		memberDTO.setToken(token);

		//주요 정보를 감춤
		memberDTO.setId(null);
        memberDTO.setPassword(null);
		
		return memberDTO;
	}

	
	

	public MemberDTO findByUsername(String username) {

		MemberDTO memberDTO = new MemberDTO();

		MemberEntity memberEntity = memberDTO.toEntity();

		Optional<MemberEntity> optional = memberRepository.findByUsername(username);

		System.out.println(username.toString());

		if (!optional.isPresent()) {
			throw new RuntimeException("해당하는 회원이 존재하지 않습니다.");
		}

		memberEntity = optional.get();

		memberDTO = MemberDTO.toDto(memberEntity);

		
		memberDTO.setId(null);
		memberDTO.setPassword(null);
	
		
		return memberDTO;

	}

	
	


	@Transactional
	public void delete(MemberDTO memberDTO) {

		MemberEntity memberEntity = memberDTO.toEntity();

		Optional<MemberEntity> optional = memberRepository.findByUsername(memberEntity.getUsername());

		if (!optional.isPresent()) {
			throw new RuntimeException("해당하는 회원이 존재하지 않습니다.");
		}

		memberEntity = optional.get();

		memberRepository.delete(memberEntity);

	}


	@Transactional
	public MemberDTO update(MemberDTO memberDTO) {

		MemberEntity memberEntity = memberDTO.toEntity();

		System.out.println(memberEntity.getUsername().toString());

		Optional<MemberEntity> optional = memberRepository.findByUsername(memberEntity.getUsername());

		System.out.println(optional.toString());

		if (!optional.isPresent()) {
			throw new RuntimeException("해당하는 회원이 존재하지 않습니다.");
		}

		memberEntity = optional.get();

		memberEntity.setPassword(memberDTO.getPassword());
		memberEntity.setName(memberDTO.getName());

		memberEntity.setHiredDate(memberDTO.getHiredDate());
		memberEntity.setDepartment(memberDTO.getDepartment());

		// 현재 날짜
		LocalDate currentDate = LocalDate.now();
		// 현재 날짜의 년도 가져오기
		int currentYear = currentDate.getYear();


		// 입사년도 추출
		// String hiredYear = memberEntity.getHiredDate().substring(0, 4);
		// 자료형 string->int로 변경
		// int inthiredYear = Integer.parseInt(hiredYear);
		int intHiredYear = Integer.parseInt(memberEntity.getHiredDate().substring(0, 4));


		// 현재년도-입사년도에 따른 연차 부여
		double yearsOfWork = currentYear - intHiredYear;
		double dayoff = 0.0;

		switch ((int) yearsOfWork) {
		    case 21:
		    case 22:
		        dayoff = 25.0;
		        break;
		    case 19:
		    case 20:
		        dayoff = 24.0;
		        break;
		    case 17:
		    case 18:
		        dayoff = 23.0;
		        break;
		    case 15:
		    case 16:
		        dayoff = 22.0;
		        break;
		    case 13:
		    case 14:
		        dayoff = 21.0;
		        break;
		    case 11:
		    case 12:
		        dayoff = 20.0;
		        break;
		    case 9:
		    case 10:
		        dayoff = 19.0;
		        break;
		    case 7:
		    case 8:
		        dayoff = 18.0;
		        break;
		    case 5:
		    case 6:
		        dayoff = 17.0;
		        break;
		    case 3:
		    case 4:
		        dayoff = 16.0;
		        break;
		    case 1:
		    case 2:
		        dayoff = 15.0;
		        break;
		    default:
		        dayoff = 11.0;
		        break;
		}

		memberEntity.setDayoff(dayoff);
		memberEntity.setRemainingDayoff(memberEntity.getDayoff()-memberEntity.getUsedDayoff());


		memberEntity.setPhoneNumber(memberDTO.getPhoneNumber());
		memberEntity.setEmail(memberDTO.getEmail());

		//update()-> createDate 설정 안함
		Date now = new Date();
		memberEntity.setUpdateDate(now);
		
		
		memberEntity.setPassword(passwordEncoder.encode(memberDTO.getPassword()));

		memberEntity = memberRepository.save(memberEntity);
		

		memberDTO = MemberDTO.toDto(memberEntity);
		memberDTO.setId(null);
		memberDTO.setPassword(null);
		
		return memberDTO;

	}
	
	public MemberDTO create(MemberDTO memberDTO) {
		MemberEntity memberEntity = memberDTO.toEntity();
		System.out.println(memberEntity);
		
		//기존 가입회원여부 (중복확인)
		Optional<MemberEntity> member = memberRepository.findByUsername(memberDTO.getUsername());
		if (member.isPresent()) {
			throw new RuntimeException("이미 존재하는 회원입니다.");
		}
		
		//현재 날짜
		LocalDate currentDate = LocalDate.now();
		//현재년도 추출
		int currentYear = currentDate.getYear();
		System.out.println("현재년도" + currentYear);

		//입사년도 추출
		// String hiredYear = memberEntity.getHiredDate().substring(0, 4);
		// 자료형 string->int로 변경
		// int inthiredYear = Integer.parseInt(hiredYear);
		int intHiredYear = Integer.parseInt(memberEntity.getHiredDate().substring(0, 4));
		System.out.println("입사년도" + intHiredYear);

		//근속년수(현재년도-입사년도)에 따른 연차 부여
		double yearsOfWork = currentYear - intHiredYear;
		double dayoff = 0.0;

		switch ((int) yearsOfWork) {
		    case 21:
		    case 22:
		        dayoff = 25.0;
		        break;
		    case 19:
		    case 20:
		        dayoff = 24.0;
		        break;
		    case 17:
		    case 18:
		        dayoff = 23.0;
		        break;
		    case 15:
		    case 16:
		        dayoff = 22.0;
		        break;
		    case 13:
		    case 14:
		        dayoff = 21.0;
		        break;
		    case 11:
		    case 12:
		        dayoff = 20.0;
		        break;
		    case 9:
		    case 10:
		        dayoff = 19.0;
		        break;
		    case 7:
		    case 8:
		        dayoff = 18.0;
		        break;
		    case 5:
		    case 6:
		        dayoff = 17.0;
		        break;
		    case 3:
		    case 4:
		        dayoff = 16.0;
		        break;
		    case 1:
		    case 2:
		        dayoff = 15.0;
		        break;
		    default:
		        dayoff = 11.0;
		        break;
		}

		memberEntity.setDayoff(dayoff);

		//첫 가입시 usedDayoff 기본값 0 부여
		memberEntity.setUsedDayoff(0.0) ;
		
		//첫 가입시 remainingDayoff = Dayoff와 동일
		memberEntity.setRemainingDayoff(memberEntity.getDayoff());

		Date now = new Date();
		memberEntity.setCreateDate(now);
		memberEntity.setUpdateDate(now);
		
		// 일반 회원만 가입하는 버전임
		memberEntity.setRole(0);
		
		//비번 암호화
		memberEntity.setPassword(passwordEncoder.encode(memberDTO.getPassword()));
		
		
		memberEntity = memberRepository.save(memberEntity);	
		
		memberDTO = MemberDTO.toDto(memberEntity);	
		
		memberDTO.setId(null);
		memberDTO.setPassword(null);	
		
		System.out.println(memberDTO+"마지막멤버디티오");
		
				
				
				
		
		
		return memberDTO;
	}
	
	
    public Page<MemberDTO> findAll(int pageNum) {

        List<Sort.Order> sortList = new ArrayList<>();
        
        //id를 기준으로 내림차순 정렬
        sortList.add(Sort.Order.desc("id"));
        
        //pageable객체 생성 : 페이지번호, 한 페이지에 보여지는 개수, 정렬 순서 설정
        Pageable pageable = PageRequest.of(pageNum, 10, Sort.by(sortList));

        //리포지토리에서 pageable사용해 페이지별로 데이터 가져옴
        Page<MemberEntity> page_entity =memberRepository.findAll(pageable);

        //엔티티->dto형태로 변환.
        Page<MemberDTO> page_dto = page_entity.map(memberEntity -> MemberDTO.toDto(memberEntity));
        
        return page_dto;

   }


//	public List<MemberDTO> findAll() {
//
//		List<MemberEntity> list_entity = memberRepository.findAll();
//		List<MemberDTO> list_dto = new ArrayList<>();
//
//		for (MemberEntity m : list_entity) {
//			list_dto.add(MemberDTO.toDto(m));
//		}
//
//		return list_dto;
//
//	}


	


}
