package kr.co.tj.auth;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import kr.co.tj.member.MemberDTO;
import kr.co.tj.member.MemberService;

@RestController
@RequestMapping("/auth")
public class AuthController {
	
	@Autowired
	private MemberService memberService;
	
	@GetMapping("/health_check")
	public String status() {
		return "돼라";
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody MemberDTO memberDTO){
		
		Map<String, Object> map = new HashMap<>();
		
		if(memberDTO==null) {
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요. 1");
		}
		
		if(memberDTO.getUsername()==null || memberDTO.getUsername().equals("")) {
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요. 2");
		}
		
		if(memberDTO.getPassword()==null || memberDTO.getPassword().equals("")) {
			throw new RuntimeException("입력한 정보가 맞는지 다시 확인해주세요. 3");
		}
		
		try {
			memberDTO = memberService.login(memberDTO);
			map.put("result", memberDTO);
			return ResponseEntity.ok().body(map);
			
		} catch (Exception e) {
			e.printStackTrace();
			map.put("result", "로그인에 실패하였습니다.");
			return ResponseEntity.badRequest().body(map);
		}
	}
	
	

	
	
	@PostMapping("/create")
	public ResponseEntity<?> create(@RequestBody MemberDTO memberDTO){
		Map<String, Object> map = new HashMap<>();
		
		if(memberDTO == null) {
			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.1");
			return ResponseEntity.badRequest().body(map);
			
		}
		
		if(memberDTO.getUsername() == null || memberDTO.getUsername().equals("")) {
			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.2");
			return ResponseEntity.badRequest().body(map);

		}
		
		if(memberDTO.getPassword() == null|| memberDTO.getPassword().equals("")) {
			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.3");
			return ResponseEntity.badRequest().body(map);


		}
		
		
		if(memberDTO.getPassword2() == null ||memberDTO.getPassword2().equals("")) {

			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.4");
			return ResponseEntity.badRequest().body(map);

		}
		
		//비밀번호와 비밀번호확인 안에 입력된 내용이 일치하는지 확인
		if(!memberDTO.getPassword().equals(memberDTO.getPassword2())){
			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.4-1");
			return ResponseEntity.badRequest().body(map);

		}
		
		if(memberDTO.getName() == null) {
			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.5");
			return ResponseEntity.badRequest().body(map);

		}
		
		if(memberDTO.getDepartment() == null) {
			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.6");
			return ResponseEntity.badRequest().body(map);

		}
		
		//입사일자 형식 지정
		 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		    String hiredDate;
		    
		    try {
		        hiredDate = memberDTO.getHiredDate();
		       
		    } catch (Exception e) {
		        map.put("result", "입사일자를 0000-00-00 형식에 맞게 입력해 주세요.");
		        return ResponseEntity.badRequest().body(map);
		    }
		    
		if(memberDTO.getHiredDate() == null) {
			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.7");
			return ResponseEntity.badRequest().body(map);

		}
		
		
		
		if(memberDTO.getPhoneNumber() == null) {
			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.8");
			return ResponseEntity.badRequest().body(map);

		}
		
		if(memberDTO.getEmail() == null) {
			map.put("result", "입력한 정보가 적절한지 다시 확인해주세요.9");
			return ResponseEntity.badRequest().body(map);

		}
		

		
		try {
			memberDTO = memberService.create(memberDTO);
			map.put("result", memberDTO);
			return ResponseEntity.ok().body(map);
			
		} catch (Exception e) {
			e.printStackTrace();
			map.put("result", e.getMessage());
			return ResponseEntity.badRequest().body(map);
		}
		
	}
	
	

}
