package kr.co.tj.dayoff;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import kr.co.tj.dayoff.dto.DayoffDTO;
import kr.co.tj.dayoff.dto.DayoffEntity;
import kr.co.tj.member.MemberDTO;
import kr.co.tj.member.MemberEntity;
import kr.co.tj.member.MemberRepository;

@Service
public class DayoffService {

	@Autowired
	private DayoffRepository dayoffRepository;

	@Autowired
	private MemberRepository memberRepository;

	@Transactional
	public DayoffDTO create(DayoffDTO dayoffDTO) {

		// 사용자가 입력한 값 받아와서 엔티티로 변환함.
		DayoffEntity dayoffEntity = dayoffDTO.toDayoffEntity();

		System.out.println(dayoffEntity);

		// 회원 정보를 가져오는 메서드 호출
		MemberEntity member = getMemberInfo(dayoffEntity.getUsername());

		// member로부터 관련정보 가져옴
		dayoffEntity.setName(member.getName());
		dayoffEntity.setDepartment(member.getDepartment());
		dayoffEntity.setHiredDate(member.getHiredDate());
		dayoffEntity.setDayoff(member.getDayoff());

		// 연차 시작일~종료일
		dayoffEntity.setStartDate(dayoffDTO.getStartDate());
		dayoffEntity.setEndDate(dayoffDTO.getEndDate());

		// 연차 구분(연차/반차 여부)
		dayoffEntity.setType(dayoffDTO.getType());

		// 연차사용일자 조정 위한 연차종료일-연차시작일 계산
		long differenceInMilies = (dayoffDTO.getEndDate().getTime()) - (dayoffDTO.getStartDate().getTime());
		double usedDayoff = ((double) differenceInMilies / (24 * 60 * 60 * 1000L)) % 365;

		// 종료일-시작일이 같지 않으면 사용일수 +1
		if (usedDayoff > 0) {
			usedDayoff += 1.0;

			// 시작일과 종료일 동일할 때 연차/반차에 따라 사용희망일수 다르게 적용
		} else if (usedDayoff == 0.0) {
			if (dayoffEntity.getType().equals("연차")) {
				usedDayoff = 1.0;
			} else if (dayoffEntity.getType().equals("오전반차") || dayoffEntity.getType().equals("오후반차")) {
				usedDayoff = 0.5;
			}
		}
		
		dayoffEntity.setUsedDayoff(usedDayoff);
		//member테이블에  변경된 연차사용내역 저장
		member.setUsedDayoff(member.getUsedDayoff() + dayoffEntity.getUsedDayoff());


//		dayoffEntity.setUsedDayoff(usedDayoff);

		// 사용가능연차 : 기본제공연차 - 사용희망연차일수
		dayoffEntity.setRemainingDayoff(dayoffEntity.getDayoff() - usedDayoff);
		
		//member테이블에 남은 연차개수 변경내역 저장
		member.setRemainingDayoff(member.getRemainingDayoff() - dayoffEntity.getUsedDayoff());

		dayoffEntity.setReason(dayoffDTO.getReason());

		dayoffEntity.setCreateDate(new Date());

		dayoffEntity = dayoffRepository.save(dayoffEntity);

		// 변경된 연차사용내역을 member테이블에 저장
		member = getMemberInfo(dayoffEntity.getUsername());

		member.setUsedDayoff(member.getUsedDayoff() + dayoffEntity.getUsedDayoff());
		member.setRemainingDayoff(member.getRemainingDayoff() - member.getUsedDayoff() - dayoffEntity.getUsedDayoff());

		member = memberRepository.save(member);
		
		return DayoffDTO.toDayoffDTO(dayoffEntity);

	}
	

	// member테이블에서 dayoff테이블의 username과 동일한 데이터 찾기
	private MemberEntity getMemberInfo(String username) {
		Optional<MemberEntity> optional = memberRepository.findByUsername(username);
		if (!optional.isPresent()) {
			throw new RuntimeException("해당하는 회원을 찾을 수 없습니다.");
		}
		return optional.get();
	}

	// 전체 연차 조회
//	public List<DayoffDTO> findAll() {
//
//		List<DayoffEntity> list_entity = dayoffRepository.findAll();
//		List<DayoffDTO> list_dto = new ArrayList<>();
//
//		for (DayoffEntity e : list_entity) {
//			list_dto.add(DayoffDTO.toDayoffDTO(e));
//		}
//
//		return list_dto;
//	}

	// 전체회원 연차
	public Page<DayoffDTO> findAll(int pageNum) {

		List<Sort.Order> sortList = new ArrayList<>();

		// id를 기준으로 내림차순 정렬
		sortList.add(Sort.Order.desc("id"));

		// pageable객체 생성 : 페이지번호, 한 페이지에 보여지는 개수, 정렬 순서 설정
		Pageable pageable = PageRequest.of(pageNum, 10, Sort.by(sortList));

		// 리포지토리에서 pageable사용해 페이지별로 데이터 가져옴
		Page<DayoffEntity> page_entity = dayoffRepository.findAll(pageable);

		// 엔티티->dto형태로 변환.
		Page<DayoffDTO> page_dto = page_entity.map(dayoffEntity -> DayoffDTO.toDayoffDTO(dayoffEntity));

		return page_dto;

	}

	// 내 연차 확인
	public DayoffDTO findByUsername(String username) {

		// 1개의 회원아이디(유저네임)로 검색한 연차상신 목록
		List<DayoffEntity> list_entity = dayoffRepository.findByUsername(username);

		// 해당 회원의 연차 사용 기록 있으면
		if (!list_entity.isEmpty()) {

			// 0) 맨 마지막 인덱스의 데이터. 나중에 값을 수정한 뒤 화면에 전달할 것임.
			int lastIndex = list_entity.size() - 1;
			DayoffEntity dayoffEntity = list_entity.get(lastIndex);
			System.out.println(dayoffEntity);

			// 1) 사용한 연차개수 토탈값 구하기 : 처음~마지막의 연차개수 계속 빼기.
			// 첫 번째 엔티티의 usedDayoff 값
			double totalUsedDayoff = list_entity.get(0).getUsedDayoff();
			System.out.println(totalUsedDayoff + ":첫번째 사용한 연차개수");

			// ~마지막 엔티티까지의 usedDayoff 값을 모두 더함
			for (int i = 1; i < list_entity.size(); i++) {
				totalUsedDayoff += list_entity.get(i).getUsedDayoff();
			}

			System.out.println(totalUsedDayoff + "개 만큼 연차 사용함");

			// 사용한 연차개수 토탈값 조정
			dayoffEntity.setUsedDayoff(totalUsedDayoff);

			// 2) 남은연차개수 조정
			dayoffEntity.setRemainingDayoff(dayoffEntity.getDayoff() - totalUsedDayoff);
			System.out.println(dayoffEntity.getDayoff() - totalUsedDayoff + "개 남음");

			System.out.println("화면에 나타낼 값:" + dayoffEntity);

			System.out.println("DTO로 변환한 값" + DayoffDTO.toDayoffDTO(dayoffEntity));
			return DayoffDTO.toDayoffDTO(dayoffEntity);

		} else {// 해당 회원의 연차 사용 내역이 없으면

			// 회원 테이블에서 해당 회원의 기본정보 조회하여 나타내기
			Optional<MemberEntity> optional = memberRepository.findByUsername(username);
			MemberEntity member = optional.get();

			DayoffEntity dayoffEntity = new DayoffEntity().builder()
					.username(member.getUsername())
					.name(member.getName())
					.department(member.getDepartment())
					.hiredDate(member.getHiredDate())
					.dayoff(member.getDayoff())
					.usedDayoff(0.0)
					.remainingDayoff(member.getDayoff())
					.build();

			DayoffDTO dayoffDTO = DayoffDTO.toDayoffDTO(dayoffEntity);
			return dayoffDTO;
		}

	}
}
