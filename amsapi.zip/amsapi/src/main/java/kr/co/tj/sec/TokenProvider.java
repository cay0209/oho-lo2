package kr.co.tj.sec;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.cfg.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import kr.co.tj.member.MemberEntity;

@Component // 객체화 하기 위한 선언
public class TokenProvider {

	private static final String SECRET_KEY = "aaaaaaaaaaaaaaaa";// 비밀키, 아무거나 길게 작성
//    private Environment env;
//
//    @Autowired
//    public TokenProvider(Environment env) {
//
//         this.env = env;
//
//    }


	// JWT : 토큰에 대한 유효성 검사
	public String validateAndGetUserId(String token) {
		//클레임: 내가 원하는 정보를 넣어보내서 필요시 빼서 쓸 수 있는 공간. username, secretkey, 만료시간 등
		Claims claims = Jwts.parser()//JWT 파서 생성
				.setSigningKey(SECRET_KEY)//JWT의 서명 검증에 사용되는 비밀키(SECRET_KEY)설정
				.parseClaimsJws(token)//메서드를 호출하여 실제로 JWT를 파싱 및 검증(JWT가 유효->해당 JWT의 내용이 Claims 객체로 반환)
				.getBody();//토큰 받으면 claims라는 객체를 넘겨줌.->유효성검사 끝.
		System.out.println(SECRET_KEY+"시크릿키");

		return claims.getSubject();// JWT의 "sub" 클레임에서 사용자 ID를 추출
								  //유효성검사 통과시 추가적으로 데이터(멤버id) 넘겨줌

	}
	

	
	
//	ROLE: 토큰에 대한 유효성 검사 및 권한 가져오기
	public String validateAndAuthority(String token) {

		Claims claims = Jwts.parser()
		.setSigningKey(SECRET_KEY)
		.parseClaimsJws(token)
		.getBody();
		
		//유효성검사 통과시 추가적으로 데이터(멤버id) 넘겨줌
		//자료형 object -> String으로 형변환해야함
		return (String)claims.get("Authority");//여기 소문자-->대문자로 바꿨더니 로그인 안되다가 됨.?
	}
	
	
	
	
	
	

	// 정상 로그인 -> 토큰 발행
	public String create(MemberEntity memberEntity) {
		String[] arr = {"ROLE_USER", "ROLE_ADMIN"};
		Map<String, Object> map = new HashMap<>();
		//index가 memberEntity.getRole()에 들어있음. 권한이 있는 map 생성.
		map.put("Authority", arr[memberEntity.getRole()]);
		
		Claims claims = Jwts.claims(map);

//		long now = new Date().getTime();
//		Date expire = new Date(now+1000*60*60);
		Date expire = Date.from(Instant.now().plus(1, ChronoUnit.HOURS));// 지금으로부터 1 시간 후의 값이 expire에 들어감

		return Jwts.builder()
				.signWith(SignatureAlgorithm.HS512, SECRET_KEY)// 헤더+페이로드+비밀키를 이용해 암호화할 때 HS512 알고리즘 사용
				.setSubject(memberEntity.getId())// 토큰의 작성자의 아이디(username은 외부에 노츨되어 있어 노출되지 않은 id 사용함)
				.setIssuer("amsapi")// 토큰이 사용될 앱:
				.setIssuedAt(new Date())// 토큰이 생성된 시각
				.setExpiration(expire)// 토큰이 만료되는 시각
//				.setClaims(claims) // map이 들어있는 claims를 넣음. -> token에 role정보 들어감.
				.claim("Authority", "ROLE_ADMIN")
				.compact();// build( )가 아니라 compact( )함수를 이용해서 문자열 객체를 만듦. 압축 후에 서명하기 위해

	}






}