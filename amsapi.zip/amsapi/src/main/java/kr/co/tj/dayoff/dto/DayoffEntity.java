package kr.co.tj.dayoff.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import kr.co.tj.member.MemberEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "dayoff")
public class DayoffEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(nullable = false)
	private String username;
	
	private String name;
	private String department;


	
	private String hiredDate;//입사일자
	private Double dayoff;//입사일에 따라 부여받은 연차개수
	
	private String type; //연차구분(연차/반차)
	
	private Date startDate;//연차 시작일
	private Date endDate;//연차 종료일
	private Double usedDayoff;// betweenDays(endDate-startDate)
	private Double remainingDayoff;//남은 연차개수:dayoff-usedDayoff
	
	private String reason; //연차사유
	
	private Date createDate; //연차상신 작성일
	private Date updateDate; //연차상신 수정일

	
	

}
