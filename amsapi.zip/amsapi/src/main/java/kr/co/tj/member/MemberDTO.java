package kr.co.tj.member;


import java.util.Date;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberDTO {
	

	private String id;
	
	private String username;
		
	private String password;
	private String password2;
	private String orgPassword;
	
	private String name;
	
	private String department;

	
	private String hiredDate;
	private Double dayoff;//입사일에 따라 부여받은 연차개수+
	private Double usedDayoff;//+사용한 연차개수:dayoff-(startDate-endDate)+
	private Double remainingDayoff;//+사용가능한 연차 :dayoff-usedDayoff

	
	private String phoneNumber;
	
	private String email;

	private Date createDate;
	private Date updateDate;
	
	private String token;
	
	private Integer role;

	
	
	// dto -> entity
	public MemberEntity toEntity() {
		return MemberEntity.builder()
				.id(id)
				.username(username)
				.name(name)
				.password(orgPassword)
				.department(department)
				.hiredDate(hiredDate)
				.dayoff(dayoff)
				.usedDayoff(usedDayoff)
				.remainingDayoff(remainingDayoff)
				.phoneNumber(phoneNumber)
				.email(email)
				.createDate(createDate)
				.updateDate(updateDate)
				.role(role)
				.build();
	}
	
	// entity -> dto
	public static MemberDTO toDto(MemberEntity memberEntity) {
		return MemberDTO.builder()
				.id(memberEntity.getId())
				.username(memberEntity.getUsername())
				.password(memberEntity.getPassword())
				.name(memberEntity.getName())
				.department(memberEntity.getDepartment())
				.hiredDate(memberEntity.getHiredDate())
				.dayoff(memberEntity.getDayoff())
				.usedDayoff(memberEntity.getUsedDayoff())
				.remainingDayoff(memberEntity.getRemainingDayoff())
				.phoneNumber(memberEntity.getPhoneNumber())
				.email(memberEntity.getEmail())
				.createDate(memberEntity.getCreateDate())
				.updateDate(memberEntity.getUpdateDate())
				.role(memberEntity.getRole())
				.build();
		
	}
	
	

}
