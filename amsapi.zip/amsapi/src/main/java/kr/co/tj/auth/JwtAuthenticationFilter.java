package kr.co.tj.auth;

import java.io.IOException;

import javax.servlet.FilterChain;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.authentication.AbstractAuthenticationToken;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import org.springframework.security.core.authority.AuthorityUtils;

import org.springframework.security.core.context.SecurityContext;

import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;

import org.springframework.stereotype.Component;

import org.springframework.web.filter.OncePerRequestFilter;

import kr.co.tj.sec.TokenProvider;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {//한번만 유효

	@Autowired
	private TokenProvider tokenProvider;//유효성검사+userid반환하는 메서드 보유.

	
	@Override
	protected void doFilterInternal(HttpServletRequest request,//모든 고객 요청 여기에
									HttpServletResponse response,//모든 응답 여기에.
									FilterChain filterChain)//요청-응답 사이에 위치. 
					throws ServletException, IOException {

		try {

			// 헤더에서 진짜 토큰만을 반환받음. parseBearerToken( )함수는 아래에 있음.
			String token = parseBearerToken(request);
//			System.out.println(token+"첫번째 토큰"); -> 여기도 무한대로 계속 나옴.. 그냥 딱 한번만 나와야 하는데..

			// token이 정상적으로 존재한다면, 그 이후 검증 작업이 진행됨.
			if (token != null && !token.equalsIgnoreCase("null")) {//ignorecase:대소문자 구분안함.

				
				System.out.println(token + "계세요?"); //여기까지는 토큰이 있음.(원래는 있으면 안됨!)
				
				// tokenProvider 기능 중 ROLE 관련 유효성 검사 기능 메서드인 validateAndGetUserId(token); 이용
				String userId = tokenProvider.validateAndGetUserId(token);//토큰 넣으면 유효성검사 함 ->최종적으로 객체 반환.
				log.info("Authentication user ID:{}", userId);
				
				String authority = tokenProvider.validateAndAuthority(token);


// 유효성 검사 결정 정상이라도
// SecurityContextHolder에 등록이 안 되어 있으면, 인증이 안 된 것과 같다.(Authentication 객체가 없이 null)
// 아래 작업은 r에 대한 작업임.
				AbstractAuthenticationToken aat = new UsernamePasswordAuthenticationToken(
						userId,
						null,
						AuthorityUtils.createAuthorityList(authority));
//						AuthorityUtils.createAuthorityList("ROLE_USER", "ROLE_ADMIN"));
//						AuthorityUtils.NO_AUTHORITIES); //위의 코드와 아래 코드는 공존 불가! role작업 후 위 코드 살림

				aat.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContext secCtx = SecurityContextHolder.createEmptyContext();
				secCtx.setAuthentication(aat);
				SecurityContextHolder.setContext(secCtx);//최종으로 SecurityContext에 저장해야 인증된 사용자로 인식함.

			}
 
		} catch (Exception e) {

			e.printStackTrace();

			System.out.println("인증에 실패했음..........................");

		}

// 이 코드를 기준으로 위에는 요청 때 실행할 코드, 밑은 응답 때 실행할 코드
		filterChain.doFilter(request, response);

	}

//토큰과 헤더 분리 -> 리퀘스트의 헤더에 들어 있는 토큰을 가져오는 기능
	private String parseBearerToken(HttpServletRequest request) {

		// 헤더 중에 이름이 Authorization인 헤더를 가져옴
		String bearerToken = request.getHeader("Authorization");
		
//		System.out.println(bearerToken+"나오나요?"); //->이 부분이 무한대로 나옴
		// 수진님도 bearerToken은 null이야..

		if (bearerToken == null || !bearerToken.startsWith("Bearer ")) {
			
//System.out.println(bearerToken + "토큰....");
			return null;

		}

		// 토큰 중에 bearer+한칸 띔 을 제외한 진짜 토큰(인덱스 7부터)만 반환함
		return bearerToken.substring(7);

	}

}