package kr.co.tj.attach;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.tj.notice.NoticeDTO;

@Service
public class UploadFileService {

	
	@Autowired
	private UploadFileRepository uploadFileRepository;
	
	
	
	public UploadFileEntity uploadFile(byte[] bytes) {
		
		UploadFileEntity entity = UploadFileEntity.builder()
				.bytes(bytes) 
				.build();
		
		return uploadFileRepository.save(entity);

	}
	
	
	public UploadFileEntity getFile(long id) {

		// TODO Auto-generated method stub

		return uploadFileRepository.getById(id);

		}






}
