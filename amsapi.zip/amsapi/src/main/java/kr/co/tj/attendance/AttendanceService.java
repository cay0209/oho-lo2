package kr.co.tj.attendance;


import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import kr.co.tj.member.MemberEntity;
import kr.co.tj.member.MemberRepository;
import kr.co.tj.notice.NoticeDTO;
import kr.co.tj.notice.NoticeEntity;


@Service
public class AttendanceService {
	
	@Autowired
	private AttendanceRepository attendanceRepository;
	
	@Autowired
	private MemberRepository memberRepository;
	
	

//출퇴근시간 기록하기
	public AttendanceDTO clickTime(AttendanceDTO attendanceDTO) {
		
		
		AttendanceEntity attendanceEntity = new ModelMapper().map(attendanceDTO, AttendanceEntity.class);
		
		// attendance의 username과 동일한 member의 저장정보 가져옴
		Optional<MemberEntity> optional = memberRepository.findByUsername(attendanceEntity.getUsername());

		if (!optional.isPresent()) {
			throw new RuntimeException("해당하는 회원을 찾을 수 없습니다.");
		}

		MemberEntity member = optional.get();
		
		attendanceEntity.setName(member.getName());
		attendanceEntity.setDepartment(member.getDepartment());
		
		// 현재 날짜 및 시간 가져오기
        Date currentDate = new Date();

        // 날짜 포맷팅을 위한 SimpleDateFormat 생성
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        // 년-월-일 시:분:초 형식으로 날짜를 문자열로 변환
        String formattedDate = sdf.format(currentDate);
        
		attendanceEntity.setClickTime(formattedDate);

		
		attendanceEntity = attendanceRepository.save(attendanceEntity);
		
		System.out.println(attendanceEntity.toString());
		
		return new ModelMapper().map(attendanceEntity, AttendanceDTO.class);
	}



// 내 출퇴근시간 보기myClickTimes()와 연결
	public List<AttendanceDTO> findByUsername(String username) {

		ModelMapper modelMapper = new ModelMapper();

		
		List<AttendanceEntity> list_entity = attendanceRepository.findByUsername(username);
		List<AttendanceDTO> list_dto = new ArrayList<AttendanceDTO>();
		
		for (AttendanceEntity a : list_entity) {
		    AttendanceDTO attendanceDTO = modelMapper.map(a, AttendanceDTO.class);
		    list_dto.add(attendanceDTO);
		}
			
		
		return list_dto;
	}



//	public List<AttendanceDTO> allClickTimes() {
//
//		ModelMapper modelMapper = new ModelMapper();
//		
//		List<AttendanceEntity> list_entity = attendanceRepository.findAll();
//		List<AttendanceDTO> list_dto = new ArrayList<AttendanceDTO>();
//		
//		for(AttendanceEntity a : list_entity) {
//			
//			AttendanceDTO attendanceDTO = modelMapper.map(a, AttendanceDTO.class);
//			
//			list_dto.add(attendanceDTO);
//		}
//		
//		return list_dto;
//	}
	
	//전체회원근태
	   public Page<AttendanceDTO> findAll(int pageNum) {

	        List<Sort.Order> sortList = new ArrayList<>();
	        
	        //id를 기준으로 내림차순 정렬
	        sortList.add(Sort.Order.desc("id"));
	        
	        //pageable객체 생성 : 페이지번호, 한 페이지에 보여지는 개수, 정렬 순서 설정
	        Pageable pageable = PageRequest.of(pageNum, 10, Sort.by(sortList));

	        //리포지토리에서 pageable사용해 페이지별로 데이터 가져옴
	        Page<AttendanceEntity> page_entity = attendanceRepository.findAll(pageable);

	        //엔티티->dto형태로 변환.
	        Page<AttendanceDTO> page_dto = page_entity.map(attendanceEntity -> AttendanceDTO.toDto(attendanceEntity));
	        
	        return page_dto;

	   }


		

	
	


	
	

}
