package kr.co.tj.dayoff;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import kr.co.tj.dayoff.dto.DayoffEntity;

public interface DayoffRepository extends JpaRepository<DayoffEntity, Long>{

	List<DayoffEntity> findByUsername(String username);


	

}
