package kr.co.tj;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.filter.CorsFilter;

import kr.co.tj.auth.JwtAuthenticationFilter;
import lombok.RequiredArgsConstructor;


@RequiredArgsConstructor
@Configuration
@EnableWebSecurity //web 보안을 활성하게 해주는 어노테이션 
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	
@Autowired
private JwtAuthenticationFilter jwtAuthenticationFilter;





	
	  //오버라이드보다는 @bean으로..
	  @Override
	    protected void configure(HttpSecurity http) throws Exception {
	        http
	        .cors() // cors에 대해 감시하겠음.
	        .and()
	        //csrf(Cross-Site Request Forgery) :사이트 간 요청 위조
	        .csrf().disable()// frontend와 backend가 분리된 상황에서는 일반적으로 csrf 감시를 안 함(비활성화).
	        // session: 전통적인 로그인 지원 방식으로 서버에 인증자에 대한 정보를 저장함.
			.sessionManagement()
	        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)// 전통적인 로그인 방식이 아니므로 session을 생성하지 않음.
	        .and()
	        //CorsFilter는 반드시 springframework 패키지에 있는 것을 선택해야 함.
	        // 이 작업은 CorsFilter를 먼저 실행한 후 우리가 만든 JwtAuthenticationFilter를 실행하라는 의미임.
	        // Cors는 서로 다른 네트워크간의 통신을 막아 버리므로 JwtAuthenticationFilter를 먼저 실행해도 cors로 인해 데이터를 주고 받을 수 없기 때문임.
	        .addFilterAfter(jwtAuthenticationFilter, CorsFilter.class)
	        .authorizeRequests()// 요청에 대해 인증을 하도록 함.
	        //antMatchers: URL 패턴을 지정(경로 정의)한 뒤+메서드로 특정 경로에 대한 접근 권한을 설정
	        .antMatchers("/**" ).permitAll()// /와  /auth로 시작하는 요청은 인증 없이도 허용함 ex)로그인, 회원가입같은 것
//			.antMatchers("/admin/**").hasRole("ADMIN")//admin은 주소에 api 안들어감
	        .antMatchers("/notice/**").anonymous()//로그인 없이도 사용가능
//	        .anyRequest().hasAnyRole("ADMIN")
	        .anyRequest().authenticated();//그 외의 요청에 대해서는 인증을 완료했을 때만 이용 가능함.

	        
	    }


	// 나중에 비밀번호 암호화나
	// 로그인 시 입력한 암호와 DB에 저장된 암호가 일치하는지 확인할 때 사용함.
	    @Bean
	    public PasswordEncoder passwordEncoder() {

	        return new BCryptPasswordEncoder();

	    }
	    
	    
	  

}
