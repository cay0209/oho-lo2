package kr.co.tj.member;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@DynamicInsert
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "members")
public class MemberEntity {
	
	@Id
	@GeneratedValue(generator = "id-uuid")
	@GenericGenerator(strategy = "uuid", name = "id-uuid")
	private String id;
	
	@Column(nullable = false, unique = true)
	private String username;
	
	@Column(nullable = false)
	private String password;
	
	@Column(nullable = false)
	private String name;
	
	private String department;

	
	private String hiredDate;
	private Double dayoff;//입사일에 따라 부여받은 연차개수+
	private Double usedDayoff;//+사용한 연차개수:dayoff-(startDate-endDate)+
	private Double remainingDayoff;//남은 연차개수:dayoff-usedDayoff

	
	private String phoneNumber;
	
	private String email;

	
	private Date createDate;
	private Date updateDate;
	
	private String token;
	
//일반유저=0, 관리자=1
	@Column
	private Integer role=1;
	
	

}
