package kr.co.tj.dayoff.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DayoffDTO {//내 연차정보 확인할 때 사용
	

	private long id;
	
	private String username;
	private String name;
	private String department;
	
	
	private String hiredDate;//입사일자	
	private int yearsOfService; //+근속년수 :현재년도 -입사일자의 년도
	private Double dayoff;//입사일에 따른 총 연차	
	
	private String type; //연차구분(연차/반차)
	//만약 type이 연차면 사용가능연차개수에서 1, 반차면 0.5 차감

	
	private Date startDate;//연차 시작일
	private Date endDate;//연차 종료일
	private Double usedDayoff;//사용한 연차 : (endDate-startDate)	
	private Double remainingDayoff;//+사용가능한 연차 :dayoff-usedDayoff

	
	
	private String reason; //연차사유
	
	private Date createDate; // 연차상신 작성일
	private Date updateDate; // 연차상신 수정일

	
	//request -> dto
	public static DayoffDTO toDayoffDTO(DayoffRequest dayoffRequest) {
		return DayoffDTO.builder()
				.username(dayoffRequest.getUsername())
				.type(dayoffRequest.getType())
				.startDate(dayoffRequest.getStartDate())
				.endDate(dayoffRequest.getEndDate())
				.reason(dayoffRequest.getReason())
				.createDate(dayoffRequest.getCreateDate())
				.updateDate(dayoffRequest.getUpdateDate())
				.build();
	}
	
	// dto -> entity
	public DayoffEntity toDayoffEntity() {
		return DayoffEntity.builder()
				.username(username)
				.name(name)
				.department(department)
				.type(type)
				.startDate(startDate)
				.endDate(endDate)
				.usedDayoff(usedDayoff)
				.remainingDayoff(remainingDayoff)
				.reason(reason)
				.createDate(createDate)
				.updateDate(updateDate)
				.build();
	}
	
	// entity -> dto
	public static DayoffDTO toDayoffDTO(DayoffEntity dayoffEntity) {
		return DayoffDTO.builder()
				.username(dayoffEntity.getUsername())
				.name(dayoffEntity.getName())
				.department(dayoffEntity.getDepartment())
				.hiredDate(dayoffEntity.getHiredDate())
				.dayoff(dayoffEntity.getDayoff())
				.type(dayoffEntity.getType())
				.startDate(dayoffEntity.getStartDate())
				.endDate(dayoffEntity.getEndDate())
				.usedDayoff(dayoffEntity.getUsedDayoff())
				.remainingDayoff(dayoffEntity.getRemainingDayoff())
				.reason(dayoffEntity.getReason())
				.createDate(dayoffEntity.getCreateDate())
				.updateDate(dayoffEntity.getUpdateDate())
				.build();
	}
	
	//dto -> response
	public DayoffResponse toDayoffResponse() {
		return DayoffResponse.builder()
				.username(username)
				.type(type)
				.hiredDate(hiredDate)
				.startDate(startDate)
				.endDate(endDate)
				.reason(reason)
				.createDate(createDate)
				.updateDate(updateDate)
				.build();
		
	}
	
	
	

}
